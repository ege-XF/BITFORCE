import os
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import List, Optional


class Settings(BaseSettings):
    # --- PROJE AYARLARI ---
    PROJECT_NAME: str = "ATÜ Bilişim MYO Backend API"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"

    # --- CORS AYARLARI ---
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]

    # Database access is optional so the API can start in read-only/offline setups.
    SUPABASE_URL: Optional[str] = None
    SUPABASE_ANON_KEY: Optional[str] = None

    # --- BOT / SCRAPER AYARLARI ---
    TARGET_SCHOOL_URL: str = "https://bilisimtekmyo.atu.edu.tr/#/"
    SCRAPE_INTERVAL_MINUTES: int = 30
    VERI_DOSYASI_YOLU: str = "okul_verileri_akisi.json"

    # Pydantic .env yapılandırması
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore"
    )


settings = Settings()
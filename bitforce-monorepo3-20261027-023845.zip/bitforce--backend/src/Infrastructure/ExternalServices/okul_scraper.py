from playwright.sync_api import sync_playwright
from typing import List, Dict, Any
import time


class OkulScraperService:
    def __init__(self, base_url: str = "https://bilisimtekmyo.atu.edu.tr"):
        self.base_url = base_url.rstrip("/")

    def scrape_akademik_kadro(self) -> List[Dict[str, Any]]:
        return []

    def scrape_duyurular(self) -> List[Dict[str, Any]]:
        return self._scrape_page(
            url=f"{self.base_url}/#!/TR/duyurular/",
            item_selector="div.DuyuruPanel",
            title_selector="h2.DuyuruAlt1Panel_Baslik, div.DuyuruTumuAlt2Panel_Baslik",
            date_selector="div.DuyuruAlt2Panel_Tarih",
            link_selector="div.DuyuruPanel[ng-click]",
        )

    def scrape_haberler(self) -> List[Dict[str, Any]]:
        return self._scrape_page(
            url=f"{self.base_url}/#!/TR/haberler/",
            item_selector="div.HaberPanel",
            title_selector="div.HaberAlt1Panel[aria-label]",
            date_selector="div.HaberAlt2Panel_Tarih",
            link_selector="a[href]",
        )

    def scrape_all(self) -> Dict[str, Any]:
        return {
            "duyurular": self.scrape_duyurular(),
            "haberler": self.scrape_haberler(),
            "akademisyenler": self.scrape_akademik_kadro(),
        }

    def _scrape_page(
        self,
        url: str,
        item_selector: str,
        title_selector: str,
        date_selector: str,
        link_selector: str,
    ) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0.0.0 Safari/537.36"
                )
            )
            page = context.new_page()
            try:
                page.goto(url, wait_until="networkidle", timeout=30000)
                time.sleep(2)

                results = page.evaluate(
                    """(opts) => {
                        const items = document.querySelectorAll(opts.itemSelector);
                        const out = [];
                        for (let i = 0; i < Math.min(items.length, 50); i++) {
                            const item = items[i];
                            const titleEl = item.querySelector(opts.titleSelector);
                            const dateEl = item.querySelector(opts.dateSelector);
                            const linkEl = item.querySelector(opts.linkSelector) || item;
                            let title = '';
                            let date = '';
                            let href = '';
                            if (titleEl) {
                                title = (titleEl.innerText || titleEl.textContent || '').trim();
                                if (!title) title = (titleEl.getAttribute('aria-label') || '').trim();
                            }
                            if (dateEl) date = (dateEl.innerText || dateEl.textContent || '').trim();
                            if (linkEl) {
                                href = linkEl.getAttribute('href') || linkEl.getAttribute('ng-click') || '';
                            }
                            if (title) {
                                let clean = title.replace(' Haber Kapak Fotoğrafı', '').replace(' Duyuru Kapak Fotoğrafı', '').trim();
                                let full = href;
                                if (full.startsWith('#') || full.startsWith('#!/')) {
                                    const path = full.replace(/^#/, '').replace(/^\\//, '');
                                    full = window.location.origin + '/#' + path;
                                } else if (!full.startsWith('http')) {
                                    if (full.startsWith('GotoURL')) {
                                        full = window.location.href;
                                    } else {
                                        full = window.location.origin + '/' + full.replace(/^\\//, '');
                                    }
                                }
                                out.push({ baslik: clean, tarih: date, baglanti: full, kaynak: window.location.href });
                            }
                        }
                        return out;
                    }""",
                    {
                        "itemSelector": item_selector,
                        "titleSelector": title_selector,
                        "dateSelector": date_selector,
                        "linkSelector": link_selector,
                    },
                )
            except Exception as e:
                print(f"Scraper error: {e}")
            finally:
                browser.close()
        return results

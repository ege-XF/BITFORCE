import os

os.environ.setdefault("SUPABASE_URL", "https://example.supabase.co")
os.environ.setdefault("SUPABASE_ANON_KEY", "test-key")

from fastapi.testclient import TestClient

from app.config import Settings
from main import app
from src.Presentation.API.v1 import router
from src.Infrastructure.Persistence.repository import SchoolRepository


class FeedRepository(SchoolRepository):
    def __init__(self):
        super().__init__(client=None)

    def get_duyurular(self, limit=20):
        return [{"id": 1, "baslik": "Kayıt", "gun": "23", "ay": "Eki"}]

    def get_haberler(self, limit=20):
        return [{"id": 2, "baslik": "Haber", "gun": "22", "ay": "Eki"}]

    def get_akademisyenler(self, limit=100):
        return []


class PopulatedRepository(FeedRepository):
    def get_akademisyenler(self, limit=100):
        return [{"ad_soyad": "Veritabanı kaydı"}]


def test_feed_endpoints_return_repository_rows():
    app.dependency_overrides[router.get_repo] = lambda: FeedRepository()

    with TestClient(app) as client:
        feed = client.get("/api/v1/feed")
        duyurular = client.get("/api/v1/duyurular")
        haberler = client.get("/api/v1/haberler")

    assert feed.status_code == 200
    assert feed.json()["duyurular"][0]["baslik"] == "Kayıt"
    assert feed.json()["haberler"][0]["baslik"] == "Haber"
    assert feed.json()["son_guncelleme"]
    assert duyurular.json()[0]["baslik"] == "Kayıt"
    assert haberler.json()[0]["baslik"] == "Haber"

    app.dependency_overrides.clear()


def test_academic_route_uses_seed_when_repository_is_empty():
    app.dependency_overrides[router.get_repo] = lambda: FeedRepository()

    response = TestClient(app).get("/api/v1/akademisyenler")

    assert response.status_code == 200
    assert response.json()["data"] == router.AKADEMISYENLER_SEED

    app.dependency_overrides.clear()


def test_academic_route_returns_database_staff_when_available():
    app.dependency_overrides[router.get_repo] = lambda: PopulatedRepository()

    response = TestClient(app).get("/api/v1/akademisyenler")

    assert response.status_code == 200
    assert response.json()["data"][0]["ad_soyad"] == "Veritabanı kaydı"

    app.dependency_overrides.clear()


def test_cors_defaults_do_not_allow_every_origin():
    assert "*" not in Settings(_env_file=None).ALLOWED_ORIGINS


def test_cors_rejects_unlisted_origins_and_allows_local_frontend():
    client = TestClient(app)

    blocked = client.get("/", headers={"Origin": "https://untrusted.example"})
    allowed = client.get("/", headers={"Origin": "http://localhost:3000"})

    assert "access-control-allow-origin" not in blocked.headers
    assert allowed.headers["access-control-allow-origin"] == "http://localhost:3000"
    assert allowed.headers["access-control-allow-credentials"] == "true"


def test_application_lifespan_does_not_start_a_scraper_thread():
    assert not hasattr(app, "lifespan"), "app should not have a custom lifespan"

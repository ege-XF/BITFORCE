from types import SimpleNamespace

from src.Infrastructure.Persistence.repository import SchoolRepository


class Query:
    def __init__(self, rows):
        self.rows = rows
        self.operations = []

    def select(self, columns):
        self.operations.append(("select", columns))
        return self

    def order(self, column, desc=False):
        self.operations.append(("order", column, desc))
        return self

    def limit(self, amount):
        self.operations.append(("limit", amount))
        return self

    def execute(self):
        return SimpleNamespace(data=self.rows)


class Client:
    def __init__(self, rows):
        self.rows = rows
        self.queries = {}

    def from_(self, table):
        query = Query(self.rows.get(table, []))
        self.queries[table] = query
        return query


def test_repository_reads_feed_tables_and_academic_staff():
    rows = {
        "duyurular": [{"id": 3, "baslik": "Duyuru"}],
        "haberler": [{"id": 4, "baslik": "Haber"}],
        "akademisyenler": [{"id": 5, "ad_soyad": "Öğretim görevlisi"}],
    }
    client = Client(rows)
    repository = SchoolRepository(client=client)

    assert repository.get_duyurular(limit=7) == rows["duyurular"]
    assert repository.get_haberler(limit=8) == rows["haberler"]
    assert repository.get_akademisyenler(limit=9) == rows["akademisyenler"]
    assert client.queries["duyurular"].operations == [
        ("select", "*"), ("order", "id", True), ("limit", 7)
    ]
    assert client.queries["haberler"].operations[-1] == ("limit", 8)
    assert client.queries["akademisyenler"].operations[-1] == ("limit", 9)


def test_repository_returns_empty_lists_when_database_is_unconfigured(monkeypatch):
    monkeypatch.setattr(
        "src.Infrastructure.Persistence.repository.get_supabase_client",
        lambda: None,
    )
    repository = SchoolRepository()

    assert repository.get_duyurular() == []
    assert repository.get_haberler() == []
    assert repository.get_akademisyenler() == []

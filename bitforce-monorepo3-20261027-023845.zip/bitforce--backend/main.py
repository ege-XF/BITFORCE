import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime

from app.config import settings
from src.Presentation.API.v1.router import api_router
from src.Infrastructure.Persistence.repository import SchoolRepository
from src.Infrastructure.ExternalServices.okul_scraper import OkulScraperService
from src.Core.Application.dtos.schemas import DuyuruCreate, HaberCreate


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

app.include_router(api_router, prefix=settings.API_V1_STR)

repo = SchoolRepository()
scraper = OkulScraperService()
scheduler = BackgroundScheduler()


def _parse_date(tarih: str) -> tuple[str, str, str]:
    try:
        dt = datetime.strptime(tarih.strip(), "%d.%m.%Y")
        return dt.strftime("%d"), dt.strftime("%m"), tarih.strip()
    except Exception:
        return ("", "", tarih.strip())


def run_scrape_job():
    try:
        data = scraper.scrape_all()
        if data.get("duyurular"):
            duyurular = []
            for d in data["duyurular"]:
                gun, ay, tarih_tam = _parse_date(d.get("tarih", ""))
                duyurular.append(
                    DuyuruCreate(
                        baslik=d.get("baslik", ""),
                        gun=gun,
                        ay=ay,
                        tarih_tam=tarih_tam,
                        detay_html=None,
                    )
                )
            repo.save_duyurular(duyurular)
        if data.get("haberler"):
            haberler = []
            for h in data["haberler"]:
                gun, ay, tarih_tam = _parse_date(h.get("tarih", ""))
                haberler.append(
                    HaberCreate(
                        baslik=h.get("baslik", ""),
                        gun=gun,
                        ay=ay,
                        gorsel_url=None,
                        detay_html=None,
                    )
                )
            repo.save_haberler(haberler)
    except Exception as e:
        print(f"Scrape job error: {e}")


@app.on_event("startup")
def startup_event():
    scheduler.add_job(
        func=run_scrape_job,
        trigger="interval",
        minutes=30,
        id="scrape_job",
        replace_existing=True,
    )
    scheduler.start()


@app.get("/", summary="Sistem Durum Kontrolü")
def root():
    return {
        "status": "online",
        "message": f"{settings.PROJECT_NAME} sorunsuz çalışıyor.",
        "docs": "/docs"
    }


@app.get("/admin/scrape-now", include_in_schema=False)
def scrape_now():
    run_scrape_job()
    return {"status": "scrape_started"}


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
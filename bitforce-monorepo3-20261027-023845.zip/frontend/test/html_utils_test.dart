import 'package:flutter_test/flutter_test.dart';
import 'package:frontend/Core/utils/html_utils.dart';

void main() {
  test('stripHtml decodes named and numeric HTML entities', () {
    expect(
      stripHtml('<p>Tom &amp; Jerry &#169; &#x1F680;</p>'),
      'Tom & Jerry © 🚀',
    );
    expect(stripHtml('&Ccedil; &uuml; &ouml; &ccedil;'), 'Ç ü ö ç');
  });
}

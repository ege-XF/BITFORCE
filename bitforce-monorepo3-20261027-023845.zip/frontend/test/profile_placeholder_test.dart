import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:frontend/pages/settings_page.dart';

void main() {
  testWidgets('settings show generic profile placeholders',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: Scaffold(body: SettingsPage())),
    );
    await tester.pump();

    expect(find.text('Öğrenci'), findsOneWidget);
    expect(find.text('Öğrenci No: —'), findsOneWidget);
    expect(find.text('Program bilgisi yok'), findsOneWidget);
    expect(find.text('— / 4.00'), findsOneWidget);
    expect(find.text('Ege Tibek'), findsNothing);
    expect(find.text('2301042017'), findsNothing);
  });

  testWidgets('logout explains that account actions are not implemented',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: Scaffold(body: SettingsPage())),
    );
    await tester.pump();
    await tester.scrollUntilVisible(
      find.text('Güvenli Çıkış'),
      400,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(find.text('Güvenli Çıkış'));
    await tester.pumpAndSettle();

    expect(find.text('Oturum yönetimi henüz desteklenmiyor.'), findsOneWidget);
    expect(find.text('Tamam'), findsOneWidget);
  });

  testWidgets('sync status does not claim a backend connection',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: Scaffold(body: SettingsPage())),
    );
    await tester.pump();

    expect(find.text('Backend entegrasyonu henüz yapılandırılmadı.'),
        findsOneWidget);
    expect(find.textContaining('Bağlı •'), findsNothing);
  });

  testWidgets('bug report does not claim submission without a backend',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: Scaffold(body: SettingsPage())),
    );
    await tester.pump();
    await tester.scrollUntilVisible(
      find.text('Hata Bildir'),
      300,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.ensureVisible(find.text('Hata Bildir'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Hata Bildir'));
    await tester.pumpAndSettle();
    expect(
      find.text('Hata bildirimi backend tarafından henüz desteklenmiyor.'),
      findsOneWidget,
    );
    await tester.tap(find.text('Kapat'));
    await tester.pump();

    expect(find.text('Teşekkürler, bildirimin iletildi'), findsNothing);
  });
}

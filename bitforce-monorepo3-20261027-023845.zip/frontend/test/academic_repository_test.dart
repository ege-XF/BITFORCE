import 'package:flutter_test/flutter_test.dart';
import 'package:frontend/data/repositories/academic_repository.dart';

void main() {
  test('does not return fabricated staff when the API request fails', () async {
    await expectLater(
      AcademicRepository().fetchAcademicStaff(),
      throwsA(isA<Exception>()),
    );
  });
}

import 'package:flutter_test/flutter_test.dart';
import 'package:frontend/Core/constants/api_constants.dart';

void main() {
  test('configured API base URL is used and normalized', () {
    expect(
      ApiConstants.resolveBaseUrl(
        configuredUrl: 'https://api.example.test/root/',
        isWeb: false,
        isAndroid: true,
        isIOS: false,
      ),
      'https://api.example.test/root',
    );
  });

  test('Android emulator uses its host-loopback default', () {
    expect(
      ApiConstants.resolveBaseUrl(
        configuredUrl: '',
        isWeb: false,
        isAndroid: true,
        isIOS: false,
      ),
      'http://10.0.2.2:8000',
    );
  });
}

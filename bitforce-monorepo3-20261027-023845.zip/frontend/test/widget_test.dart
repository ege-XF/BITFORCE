// The live feed is intentionally not required for this static UI smoke test.
import 'package:flutter_test/flutter_test.dart';

import 'package:frontend/main.dart';

void main() {
  testWidgets('app smoke test renders the home screen without feed data',
      (WidgetTester tester) async {
    await tester.pumpWidget(const AtuObsApp());

    expect(find.text('Hoş Geldin,'), findsOneWidget);
    expect(find.text('Hızlı Erişim'), findsOneWidget);
    expect(find.text('Canlı Akış'), findsOneWidget);
    expect(find.text('Öğrenci'), findsOneWidget);
  });
}

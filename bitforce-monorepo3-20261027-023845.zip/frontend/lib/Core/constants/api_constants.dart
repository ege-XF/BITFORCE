import 'dart:io' show Platform;
import 'package:flutter/foundation.dart';

class ApiConstants {
  static const String _configuredBaseUrl =
      String.fromEnvironment('API_BASE_URL');

  static String get baseUrl => resolveBaseUrl(
        configuredUrl: _configuredBaseUrl,
        isWeb: kIsWeb,
        isAndroid: !kIsWeb && Platform.isAndroid,
        isIOS: !kIsWeb && Platform.isIOS,
      );

  /// Resolves a dart-define URL, or a safe local development default.
  static String resolveBaseUrl({
    required String configuredUrl,
    required bool isWeb,
    required bool isAndroid,
    required bool isIOS,
  }) {
    final configured = configuredUrl.trim();
    if (configured.isNotEmpty) {
      return configured.replaceFirst(RegExp(r'/+$'), '');
    }
    if (isAndroid) return 'http://10.0.2.2:8000';
    if (isWeb || isIOS) return 'http://127.0.0.1:8000';
    return 'http://127.0.0.1:8000';
  }

  static String get feedEndpoint => '$baseUrl/api/v1/feed';
  static String get duyurularEndpoint => '$baseUrl/api/v1/duyurular';
  static String get haberlerEndpoint => '$baseUrl/api/v1/haberler';
  static String get akademisyenlerEndpoint => '$baseUrl/api/v1/akademisyenler';
}

/// Removes markup and decodes common named and numeric HTML character references.
String stripHtml(String htmlString) {
  final text = htmlString.replaceAll(RegExp(r'<[^>]*>', multiLine: true), '');
  return text
      .replaceAllMapped(
        RegExp(r'&(#(?:x[0-9a-f]+|[0-9]+)|[a-z][a-z0-9]+);',
            caseSensitive: false),
        (match) => _decodeEntity(match[0]!),
      )
      .trim();
}

const _namedEntities = <String, String>{
  'amp': '&',
  'lt': '<',
  'gt': '>',
  'quot': '"',
  'apos': "'",
  'nbsp': '\u00a0',
  'copy': '©',
  'reg': '®',
  'trade': '™',
  'ndash': '–',
  'mdash': '—',
  'lsquo': '‘',
  'rsquo': '’',
  'ldquo': '“',
  'rdquo': '”',
  'hellip': '…',
  'bull': '•',
  'euro': '€',
  'pound': '£',
  'yen': '¥',
  'cent': '¢',
  'times': '×',
  'divide': '÷',
  'plusmn': '±',
  'deg': '°',
  'Ccedil': 'Ç',
  'Ouml': 'Ö',
  'Uuml': 'Ü',
  'agrave': 'à',
  'aacute': 'á',
  'acirc': 'â',
  'atilde': 'ã',
  'auml': 'ä',
  'aring': 'å',
  'aelig': 'æ',
  'ccedil': 'ç',
  'egrave': 'è',
  'eacute': 'é',
  'ecirc': 'ê',
  'euml': 'ë',
  'igrave': 'ì',
  'iacute': 'í',
  'icirc': 'î',
  'iuml': 'ï',
  'eth': 'ð',
  'ntilde': 'ñ',
  'ograve': 'ò',
  'oacute': 'ó',
  'ocirc': 'ô',
  'otilde': 'õ',
  'ouml': 'ö',
  'oslash': 'ø',
  'ugrave': 'ù',
  'uacute': 'ú',
  'ucirc': 'û',
  'uuml': 'ü',
  'yacute': 'ý',
  'thorn': 'þ',
  'yuml': 'ÿ',
  'szlig': 'ß',
};

String _decodeEntity(String entity) {
  final name = entity.substring(1, entity.length - 1);
  if (name.startsWith('#')) {
    final isHex = name.length > 1 && name[1].toLowerCase() == 'x';
    final digits = name.substring(isHex ? 2 : 1);
    final codePoint = int.tryParse(digits, radix: isHex ? 16 : 10);
    if (codePoint != null &&
        codePoint > 0 &&
        codePoint <= 0x10ffff &&
        (codePoint < 0xd800 || codePoint > 0xdfff)) {
      return String.fromCharCode(codePoint);
    }
    return entity;
  }
  return _namedEntities[name] ?? _namedEntities[name.toLowerCase()] ?? entity;
}

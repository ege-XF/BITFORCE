import '../../Core/constants/api_constants.dart';
import '../models/academic_staff.dart';
import 'base_repository.dart';

class AcademicRepository extends BaseRepository {
  Future<List<AcademicStaff>> fetchAcademicStaff() async {
    final data = await getJson(ApiConstants.akademisyenlerEndpoint);

    if (data['data'] is! List) {
      throw const FormatException('Akademisyen yanıt biçimi geçersiz.');
    }

    return (data['data'] as List)
        .whereType<Map<String, dynamic>>()
        .map(AcademicStaff.fromJson)
        .toList(growable: false);
  }
}

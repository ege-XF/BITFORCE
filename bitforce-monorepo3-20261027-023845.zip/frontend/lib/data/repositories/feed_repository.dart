import '../../Core/constants/api_constants.dart';
import '../models/announcement.dart';
import 'base_repository.dart';

class FeedRepository extends BaseRepository {
  Future<List<Announcement>> fetchLiveFeed() async {
    final data = await getJson(ApiConstants.feedEndpoint);
    final List<Announcement> items = [];

    if (data['duyurular'] is List) {
      for (var item in data['duyurular']) {
        if (item is Map<String, dynamic>) {
          items.add(Announcement.fromJson(item, 'Duyuru'));
        }
      }
    }
    if (data['haberler'] is List) {
      for (var item in data['haberler']) {
        if (item is Map<String, dynamic>) {
          items.add(Announcement.fromJson(item, 'Haber'));
        }
      }
    }
    return items;
  }
}

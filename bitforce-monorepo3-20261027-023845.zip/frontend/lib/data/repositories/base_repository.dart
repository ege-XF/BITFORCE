import 'dart:convert';
import 'package:http/http.dart' as http;

class BaseRepository {
  Future<Map<String, dynamic>> getJson(String endpoint) async {
    final response = await http
        .get(Uri.parse(endpoint))
        .timeout(const Duration(seconds: 5));
    if (response.statusCode != 200) {
      throw Exception('Sunucu yanıt vermedi (${response.statusCode})');
    }
    return json.decode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
  }
}

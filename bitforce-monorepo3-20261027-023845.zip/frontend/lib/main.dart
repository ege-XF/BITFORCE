// ATÜ OBS – Single-file Flutter UI + Live API Integration
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import 'pages/home_page.dart';
import 'pages/groups_page.dart';
import 'pages/settings_page.dart';

void main() => runApp(const AtuObsApp());

/* ───────────────────────── THEME & TOKENS ───────────────────────── */

class AppColors {
  static const navy = Color(0xFF0F172A);
  static const royal = Color(0xFF1E3A8A);
  static const accent = Color(0xFF3B82F6);
  static const accentDeep = Color(0xFF2563EB);
  static const darkBg = Color(0xFF111827);
  static const green = Color(0xFF22C55E);
  static const violet = Color(0xFF8B5CF6);
  static const teal = Color(0xFF14B8A6);
  static const amber = Color(0xFFF59E0B);
  static const danger = Color(0xFFEF4444);

  static const brand = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [accent, royal],
  );
}

class Pal {
  final bool dark;
  const Pal(this.dark);
  factory Pal.of(BuildContext c) =>
      Pal(Theme.of(c).brightness == Brightness.dark);

  Color get text => dark ? Colors.white : AppColors.navy;
  Color get sub => dark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
  Color get glass => dark
      ? Colors.white.withValues(alpha: 0.06)
      : Colors.white.withValues(alpha: 0.72);
  Color get glassBorder => dark
      ? Colors.white.withValues(alpha: 0.10)
      : Colors.black.withValues(alpha: 0.06);

  /// Input / hücre / segment gibi iç yüzeylerde ortak dolgu rengi.
  Color get fill => dark
      ? Colors.white.withValues(alpha: 0.07)
      : Colors.black.withValues(alpha: 0.05);

  TextStyle h(double size, {FontWeight w = FontWeight.w600, Color? color}) =>
      GoogleFonts.poppins(fontSize: size, fontWeight: w, color: color ?? text);

  TextStyle body(double size, {FontWeight w = FontWeight.w400, Color? color}) =>
      GoogleFonts.inter(fontSize: size, fontWeight: w, color: color ?? sub);
}

final themeNotifier = ValueNotifier<ThemeMode>(ThemeMode.dark);
final notifEnabled = ValueNotifier<bool>(true);

Color catColor(String c) {
  switch (c) {
    case 'Haber':
    case 'Proje':
      return AppColors.violet;
    case 'Etkinlik':
      return AppColors.teal;
    case 'Çalışma':
      return AppColors.amber;
    default:
      return AppColors.accent;
  }
}

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg, style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 110),
      backgroundColor: AppColors.accentDeep,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ));
}

/* ───────────────────────── APP ROOT ───────────────────────── */

class AtuObsApp extends StatelessWidget {
  const AtuObsApp({super.key});

  ThemeData _build(Brightness b) {
    final base = ThemeData(
      useMaterial3: true,
      brightness: b,
      colorScheme:
          ColorScheme.fromSeed(seedColor: AppColors.accent, brightness: b),
    );
    return base.copyWith(
      textTheme: GoogleFonts.interTextTheme(base.textTheme),
      scaffoldBackgroundColor: Colors.transparent,
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, mode, __) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'ATÜ OBS',
        themeMode: mode,
        theme: _build(Brightness.light),
        darkTheme: _build(Brightness.dark),
        home: const HomeShell(),
      ),
    );
  }
}

/* ───────────────────────── SHARED WIDGETS ───────────────────────── */

class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: p.dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
      child: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: p.dark
                      ? const [
                          AppColors.darkBg,
                          Color(0xFF0F1E4A),
                          AppColors.darkBg
                        ]
                      : const [
                          Color(0xFFF8FAFC),
                          Color(0xFFDBEAFE),
                          Color(0xFFF1F5F9)
                        ],
                ),
              ),
            ),
          ),
          const Positioned(
              top: -90,
              right: -70,
              child: _Glow(color: AppColors.accent, size: 280)),
          const Positioned(
              bottom: 140,
              left: -110,
              child: _Glow(color: AppColors.royal, size: 300)),
          child,
        ],
      ),
    );
  }
}

class _Glow extends StatelessWidget {
  final Color color;
  final double size;
  const _Glow({required this.color, required this.size});

  @override
  Widget build(BuildContext context) {
    final dark = Pal.of(context).dark;
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [
            color.withValues(alpha: dark ? 0.38 : 0.22),
            color.withValues(alpha: 0),
          ]),
        ),
      ),
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final VoidCallback? onTap;
  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 22,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Material(
          color: p.glass,
          child: InkWell(
            onTap: onTap,
            child: Container(
              padding: padding,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(radius),
                border: Border.all(color: p.glassBorder),
              ),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}

class GradientButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback onTap;
  final bool compact;
  const GradientButton({
    super.key,
    required this.label,
    required this.onTap,
    this.icon,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: AppColors.brand,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: AppColors.accent.withValues(alpha: 0.38),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Padding(
            padding: EdgeInsets.symmetric(
                horizontal: compact ? 14 : 18, vertical: compact ? 9 : 13),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[
                  Icon(icon, size: 18, color: Colors.white),
                  const SizedBox(width: 6),
                ],
                Text(label,
                    style: GoogleFonts.inter(
                        fontSize: compact ? 12.5 : 14,
                        fontWeight: FontWeight.w700,
                        color: Colors.white)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CategoryTag extends StatelessWidget {
  final String label;
  const CategoryTag(this.label, {super.key});

  @override
  Widget build(BuildContext context) {
    final c = catColor(label);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(
        color: c.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(label,
          style: GoogleFonts.inter(
              fontSize: 10.5, fontWeight: FontWeight.w700, color: c)),
    );
  }
}

class FilterChipX extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const FilterChipX(
      {super.key,
      required this.label,
      required this.selected,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          gradient: selected ? AppColors.brand : null,
          color: selected ? null : p.glass,
          borderRadius: BorderRadius.circular(20),
          border:
              Border.all(color: selected ? Colors.transparent : p.glassBorder),
        ),
        child: Text(label,
            style: GoogleFonts.inter(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: selected ? Colors.white : p.sub)),
      ),
    );
  }
}

/// Yatay kaydırılabilir filtre çipleri (Ana Sayfa, Gruplar, Grup oluşturma).
class FilterBar extends StatelessWidget {
  final List<String> options;
  final String selected;
  final ValueChanged<String> onSelected;
  const FilterBar({
    super.key,
    required this.options,
    required this.selected,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (final o in options)
            FilterChipX(
              label: o,
              selected: selected == o,
              onTap: () => onSelected(o),
            ),
        ],
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionTitle(this.text, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Expanded(child: Text(text, style: p.h(16))),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

class InitialsAvatar extends StatelessWidget {
  final String initials;
  final double size;
  const InitialsAvatar(this.initials, {super.key, this.size = 48});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: AppColors.brand,
        boxShadow: [
          BoxShadow(
              color: AppColors.accent.withValues(alpha: 0.35), blurRadius: 14),
        ],
      ),
      child: Text(initials,
          style: GoogleFonts.poppins(
              fontSize: size * 0.34,
              fontWeight: FontWeight.w700,
              color: Colors.white)),
    );
  }
}

Future<void> showGlassSheet(
  BuildContext context, {
  required String title,
  required Widget child,
}) {
  return showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      final p = Pal.of(ctx);
      return Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
            child: Container(
              color: p.dark
                  ? AppColors.navy.withValues(alpha: 0.88)
                  : Colors.white.withValues(alpha: 0.94),
              padding: const EdgeInsets.fromLTRB(22, 12, 22, 20),
              child: SafeArea(
                top: false,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: p.sub.withValues(alpha: 0.4),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(title, style: p.h(18)),
                    const SizedBox(height: 14),
                    child,
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    },
  );
}

InputDecoration glassField(Pal p, String hint) => InputDecoration(
      hintText: hint,
      hintStyle: p.body(14),
      filled: true,
      fillColor: p.fill,
      border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );

/* ───────────────────────── SHELL + GLASS BOTTOM BAR ───────────────────────── */

class NavItemData {
  final IconData icon;
  final String label;
  final int badge;
  final Color badgeColor;
  const NavItemData(this.icon, this.label,
      {this.badge = 0, this.badgeColor = AppColors.green});
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  static const _pages = <Widget>[
    HomePage(),
    GroupsPage(),
    SettingsPage(),
  ];

  static const _items = <NavItemData>[
    NavItemData(Icons.home_outlined, 'Ana Sayfa',
        badge: 3, badgeColor: AppColors.accent),
    NavItemData(Icons.groups_outlined, 'Gruplar', badge: 2),
    NavItemData(Icons.settings_outlined, 'Ayarlar'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: AppBackground(
        child: SafeArea(
          bottom: false,
          child: IndexedStack(index: _index, children: _pages),
        ),
      ),
      bottomNavigationBar: GlassBottomBar(
        index: _index,
        items: _items,
        onTap: (i) => setState(() => _index = i),
      ),
    );
  }
}

class GlassBottomBar extends StatelessWidget {
  final int index;
  final List<NavItemData> items;
  final ValueChanged<int> onTap;
  const GlassBottomBar(
      {super.key,
      required this.index,
      required this.items,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final bottom = MediaQuery.of(context).padding.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(18, 0, 18, math.max(bottom, 12) + 4),
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(32),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: p.dark ? 0.45 : 0.12),
              blurRadius: 30,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(32),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 28, sigmaY: 28),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              decoration: BoxDecoration(
                color: p.dark
                    ? const Color(0xFF0B1220).withValues(alpha: 0.55)
                    : Colors.white.withValues(alpha: 0.7),
                borderRadius: BorderRadius.circular(32),
                border: Border.all(color: p.glassBorder),
              ),
              child: Row(
                children: [
                  for (int i = 0; i < items.length; i++)
                    Expanded(
                      child: _NavButton(
                        data: items[i],
                        active: i == index,
                        onTap: () => onTap(i),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  final NavItemData data;
  final bool active;
  final VoidCallback onTap;
  const _NavButton(
      {required this.data, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 320),
            curve: Curves.easeOutCubic,
            width: active ? 76 : 48,
            height: 38,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(19),
              gradient: active
                  ? LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        AppColors.accent.withValues(alpha: 0.38),
                        AppColors.accent.withValues(alpha: 0.10),
                      ],
                    )
                  : null,
              border: Border.all(
                  color: active
                      ? AppColors.accent.withValues(alpha: 0.5)
                      : Colors.transparent),
              boxShadow: active
                  ? [
                      BoxShadow(
                        color: AppColors.accent.withValues(alpha: 0.35),
                        blurRadius: 16,
                      ),
                    ]
                  : const [],
            ),
            child: Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.center,
              children: [
                AnimatedScale(
                  scale: active ? 1.12 : 1,
                  duration: const Duration(milliseconds: 260),
                  curve: Curves.easeOutBack,
                  child: Icon(
                    data.icon,
                    size: 24,
                    color: active
                        ? (p.dark ? Colors.white : AppColors.accentDeep)
                        : p.sub,
                  ),
                ),
                if (data.badge > 0)
                  Positioned(
                    top: -4,
                    right: active ? 8 : 0,
                    child: Container(
                      constraints:
                          const BoxConstraints(minWidth: 17, minHeight: 17),
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: data.badgeColor,
                        borderRadius: BorderRadius.circular(9),
                        boxShadow: [
                          BoxShadow(
                              color: data.badgeColor.withValues(alpha: 0.55),
                              blurRadius: 8),
                        ],
                      ),
                      child: Text('${data.badge}',
                          style: GoogleFonts.inter(
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              color: Colors.white)),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 3),
          AnimatedDefaultTextStyle(
            duration: const Duration(milliseconds: 250),
            style: GoogleFonts.inter(
              fontSize: 11,
              fontWeight: active ? FontWeight.w700 : FontWeight.w500,
              color: active ? p.text : p.sub,
            ),
            child: Text(data.label),
          ),
        ],
      ),
    );
  }
}

// Ana Sayfa
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:frontend/data/models/announcement.dart';
import 'package:frontend/data/repositories/feed_repository.dart';
import 'package:frontend/main.dart';

class QuickItem {
  final IconData icon;
  final String label;
  final List<Color> colors;
  final List<String> lines;
  const QuickItem(this.icon, this.label, this.colors, this.lines);
}

const _quick = <QuickItem>[
  QuickItem(Icons.event_note_outlined, 'Sınav\nTakvimi', [
    Color(0xFF3B82F6),
    Color(0xFF1D4ED8)
  ], [
    'Veri Yapıları • 27 Eki, 10:00',
    'Matematik II • 29 Eki, 13:30',
    'Web Programlama • 2 Kas, 09:00',
  ]),
  QuickItem(Icons.calendar_view_week_outlined, 'Ders\nProgramı', [
    Color(0xFF6366F1),
    Color(0xFF3730A3)
  ], [
    'Pzt 09:00 • Algoritma',
    'Sal 13:00 • Veri Tabanı',
    'Çar 10:00 • Mobil Programlama',
  ]),
  QuickItem(Icons.restaurant_menu_outlined, 'Yemekhane\nMenüsü', [
    Color(0xFF0EA5E9),
    Color(0xFF1E40AF)
  ], [
    'Çorba • Mercimek',
    'Ana yemek • Tavuk sote',
    'Yan • Pilav & Salata',
    'Tatlı • Sütlaç',
  ]),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const _filters = ['Tümü', 'Duyuru', 'Haber'];

  final FeedRepository _repository = FeedRepository();
  String _filter = 'Tümü';
  List<Announcement> _liveAnnouncements = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchFeed();
  }

  Future<void> _fetchFeed() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final data = await _repository.fetchLiveFeed();
      if (!mounted) return;
      final now = DateTime.now();
      final oneYearAgo = DateTime(now.year - 1, now.month, now.day);
      final filtered = data.where((a) {
        final d = a.date;
        if (d == null) return true;
        return d.isAfter(oneYearAgo) || d.difference(oneYearAgo).inDays.abs() <= 1;
      }).toList();
      filtered.sort((a, b) {
        final da = a.date;
        final db = b.date;
        if (da == null && db == null) return 0;
        if (da == null) return 1;
        if (db == null) return -1;
        return db.compareTo(da);
      });
      setState(() {
        _liveAnnouncements = filtered;
        _isLoading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _errorMessage =
            'Backend servisine bağlanılamadı. Lütfen sunucunun çalıştığından emin olun.';
        _isLoading = false;
      });
    }
  }

  Widget _buildFeed(Pal p) {
    if (_isLoading) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (_errorMessage != null) {
      return GlassCard(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(Icons.wifi_off_rounded,
                size: 36, color: AppColors.danger),
            const SizedBox(height: 10),
            Text(_errorMessage!,
                textAlign: TextAlign.center, style: p.body(13)),
            const SizedBox(height: 14),
            GradientButton(
              label: 'Tekrar Dene',
              icon: Icons.refresh_rounded,
              compact: true,
              onTap: _fetchFeed,
            ),
          ],
        ),
      );
    }

    final list = _filter == 'Tümü'
        ? _liveAnnouncements
        : _liveAnnouncements.where((a) => a.category == _filter).toList();

    if (list.isEmpty) {
      return Padding(
        padding: const EdgeInsets.all(20),
        child: Text('Henüz duyuru veya haber bulunamadı.', style: p.body(14)),
      );
    }

    return Column(
      children: [
        for (final a in list) ...[
          _AnnouncementCard(a: a),
          const SizedBox(height: 12),
        ],
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 130),
      children: [
        // Header (Profil ve Bildirimler)
        Row(
          children: [
            const InitialsAvatar('Ö'),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Hoş Geldin,', style: p.body(13)),
                  Text('Öğrenci', style: p.h(20, w: FontWeight.w700)),
                ],
              ),
            ),
            GestureDetector(
              onTap: () => toast(context, '3 yeni bildirimin var'),
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  GlassCard(
                    radius: 16,
                    padding: const EdgeInsets.all(11),
                    child: Icon(Icons.notifications_none_rounded,
                        color: p.text, size: 22),
                  ),
                  Positioned(
                    top: -2,
                    right: -2,
                    child: Container(
                      width: 14,
                      height: 14,
                      decoration: BoxDecoration(
                        color: AppColors.green,
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: p.dark ? AppColors.darkBg : Colors.white,
                            width: 2),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 26),

        // Hızlı Erişim
        const SectionTitle('Hızlı Erişim'),
        Row(
          children: [
            for (int i = 0; i < _quick.length; i++) ...[
              Expanded(child: _QuickCard(item: _quick[i])),
              if (i != _quick.length - 1) const SizedBox(width: 10),
            ],
          ],
        ),
        const SizedBox(height: 28),

        // Canlı Akış
        SectionTitle(
          'Canlı Akış',
          trailing: GestureDetector(
            onTap: _fetchFeed,
            child: const Icon(Icons.refresh_rounded,
                size: 20, color: AppColors.accent),
          ),
        ),
        FilterBar(
          options: _filters,
          selected: _filter,
          onSelected: (f) => setState(() => _filter = f),
        ),
        const SizedBox(height: 14),
        _buildFeed(p),
      ],
    );
  }
}

class _QuickCard extends StatelessWidget {
  final QuickItem item;
  const _QuickCard({required this.item});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return GlassCard(
      radius: 20,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
      onTap: () => showGlassSheet(
        context,
        title: item.label.replaceAll('\n', ' '),
        child: Column(
          children: [
            for (final l in item.lines)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 7),
                child: Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                          gradient: AppColors.brand, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                        child: Text(l,
                            style:
                                p.body(14, color: p.text, w: FontWeight.w500))),
                  ],
                ),
              ),
          ],
        ),
      ),
      child: Column(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: item.colors),
              boxShadow: [
                BoxShadow(
                    color: item.colors.first.withValues(alpha: 0.4),
                    blurRadius: 12),
              ],
            ),
            child: Icon(item.icon, color: Colors.white, size: 22),
          ),
          const SizedBox(height: 10),
          Text(item.label,
              textAlign: TextAlign.center,
              style: p.body(12, color: p.text, w: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _AnnouncementCard extends StatelessWidget {
  final Announcement a;
  const _AnnouncementCard({required this.a});

  void _openDetail(BuildContext context, Pal p) {
    showGlassSheet(
      context,
      title: a.title,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CategoryTag(a.category),
          const SizedBox(height: 12),
          Text(a.body,
              style: p.body(14.5, color: p.text).copyWith(height: 1.5)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return GlassCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 52,
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: const BoxDecoration(
              gradient: AppColors.brand,
              borderRadius: BorderRadius.all(Radius.circular(14)),
            ),
            child: Column(
              children: [
                Text(a.day,
                    style: GoogleFonts.poppins(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        height: 1.1)),
                Text(a.month,
                    style: GoogleFonts.inter(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w700,
                        color: Colors.white70)),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CategoryTag(a.category),
                const SizedBox(height: 7),
                Text(a.title, style: p.h(14.5)),
                const SizedBox(height: 4),
                Text(a.summary,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: p.body(12.5)),
                const SizedBox(height: 6),
                Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () => _openDetail(context, p),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('Detay',
                            style: p.body(12.5,
                                color: AppColors.accent, w: FontWeight.w700)),
                        const SizedBox(width: 2),
                        const Icon(Icons.arrow_forward_rounded,
                            size: 15, color: AppColors.accent),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

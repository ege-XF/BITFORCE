// Ayarlar Sayfası
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:frontend/data/models/academic_staff.dart';
import 'package:frontend/data/repositories/academic_repository.dart';
import 'package:frontend/main.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  Widget _divider(Pal p) =>
      Divider(height: 1, indent: 64, color: p.glassBorder);

  void _reportBug(BuildContext context) {
    final p = Pal.of(context);
    showGlassSheet(
      context,
      title: 'Hata Bildir',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Hata bildirimi backend tarafından henüz desteklenmiyor.',
            style: p.body(14, color: p.text),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: GradientButton(
              label: 'Kapat',
              icon: Icons.close_rounded,
              onTap: () => Navigator.pop(context),
            ),
          ),
        ],
      ),
    );
  }

  static final _academicRepository = AcademicRepository();

  void _academicGuide(BuildContext context) {
    final p = Pal.of(context);
    showGlassSheet(
      context,
      title: 'Akademisyen İletişim Rehberi',
      child: FutureBuilder<List<AcademicStaff>>(
        future: _academicRepository.fetchAcademicStaff(),
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: CircularProgressIndicator(),
              ),
            );
          }

          final staff = snapshot.data;
          if (snapshot.hasError || staff == null || staff.isEmpty) {
            return Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'Akademisyen bilgileri yüklenemedi. Lütfen backend servisini kontrol edin.',
                style: p.body(13),
              ),
            );
          }

          return ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.6,
            ),
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: staff.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) => _AcademicTile(staff: staff[i]),
            ),
          );
        },
      ),
    );
  }

  void _logout(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text('Güvenli Çıkış',
            style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
        content: Text('Oturum yönetimi henüz desteklenmiyor.',
            style: GoogleFonts.inter()),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Tamam'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 130),
      children: [
        Text('Ayarlar', style: p.h(22, w: FontWeight.w700)),
        const SizedBox(height: 18),

        // Profil özeti
        GlassCard(
          child: Column(
            children: [
              Row(
                children: [
                  const InitialsAvatar('Ö', size: 62),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Öğrenci', style: p.h(17, w: FontWeight.w700)),
                        const SizedBox(height: 2),
                        Text('Öğrenci No: —', style: p.body(12.5)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Row(
                children: [
                  Expanded(child: _InfoCell('Bölüm', 'Program bilgisi yok')),
                  SizedBox(width: 10),
                  Expanded(child: _InfoCell('Sınıf', '—')),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Text('AGNO', style: p.body(12.5, w: FontWeight.w600)),
                  const Spacer(),
                  Text('— / 4.00',
                      style:
                          p.h(14, color: AppColors.accent, w: FontWeight.w700)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),

        // Tercihler
        const SectionTitle('Tercihler'),
        GlassCard(
          padding: EdgeInsets.zero,
          child: Column(
            children: [
              ValueListenableBuilder<bool>(
                valueListenable: notifEnabled,
                builder: (_, on, __) => SettingRow(
                  icon: Icons.notifications_active_outlined,
                  title: 'Otomatik Duyuru Bildirimleri',
                  trailing: Switch(
                    value: on,
                    activeThumbColor: Colors.white,
                    activeTrackColor: AppColors.accent,
                    onChanged: (v) => notifEnabled.value = v,
                  ),
                  onTap: () => notifEnabled.value = !on,
                ),
              ),
              _divider(p),
              const SettingRow(
                icon: Icons.contrast_outlined,
                title: 'Tema',
                trailing: _ThemeSegment(),
              ),
              _divider(p),
              const SettingRow(
                icon: Icons.cloud_off_outlined,
                title: 'Supabase Senkronizasyonu',
                subtitle: 'Backend entegrasyonu henüz yapılandırılmadı.',
                trailing: Icon(Icons.cloud_off_outlined, size: 22),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),

        // Destek
        const SectionTitle('Destek'),
        GlassCard(
          padding: EdgeInsets.zero,
          child: Column(
            children: [
              SettingRow(
                icon: Icons.bug_report_outlined,
                title: 'Hata Bildir',
                onTap: () => _reportBug(context),
              ),
              _divider(p),
              SettingRow(
                icon: Icons.contacts_outlined,
                title: 'Akademisyen İletişim Rehberi',
                onTap: () => _academicGuide(context),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),

        // Çıkış
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Material(
            color: AppColors.danger.withValues(alpha: 0.12),
            child: InkWell(
              onTap: () => _logout(context),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 15),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                      color: AppColors.danger.withValues(alpha: 0.3)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.logout_rounded,
                        color: AppColors.danger, size: 20),
                    const SizedBox(width: 8),
                    Text('Güvenli Çıkış',
                        style: GoogleFonts.inter(
                            fontSize: 14.5,
                            fontWeight: FontWeight.w700,
                            color: AppColors.danger)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _AcademicTile extends StatelessWidget {
  final AcademicStaff staff;
  const _AcademicTile({required this.staff});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final hasRoom = staff.room.isNotEmpty && staff.room != '-';
    return GlassCard(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          InitialsAvatar(staff.name.isNotEmpty ? staff.name[0] : 'A', size: 44),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${staff.title} ${staff.name}', style: p.h(14)),
                const SizedBox(height: 2),
                Text(staff.department, style: p.body(11.5)),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(Icons.email_outlined, size: 13, color: p.sub),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(staff.email,
                          overflow: TextOverflow.ellipsis,
                          style: p.body(11.5, color: AppColors.accent)),
                    ),
                    if (hasRoom) ...[
                      const SizedBox(width: 8),
                      Icon(Icons.meeting_room_outlined, size: 13, color: p.sub),
                      const SizedBox(width: 2),
                      Text(staff.room, style: p.body(11.5)),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoCell extends StatelessWidget {
  final String label, value;
  const _InfoCell(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.fill,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: p.body(11.5)),
          const SizedBox(height: 3),
          Text(value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: p.body(13, color: p.text, w: FontWeight.w600)),
        ],
      ),
    );
  }
}

class SettingRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final Color iconColor;
  const SettingRow({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
    this.iconColor = AppColors.accent,
  });

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: iconColor.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, size: 20, color: iconColor),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: p.body(14, color: p.text, w: FontWeight.w600)),
                  if (subtitle != null) ...[
                    const SizedBox(height: 2),
                    Text(subtitle!, style: p.body(12)),
                  ],
                ],
              ),
            ),
            trailing ??
                Icon(Icons.chevron_right_rounded, color: p.sub, size: 22),
          ],
        ),
      ),
    );
  }
}

class _ThemeSegment extends StatelessWidget {
  const _ThemeSegment();

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, mode, __) {
        Widget seg(String label, IconData icon, ThemeMode m) {
          final sel = mode == m;
          return GestureDetector(
            onTap: () => themeNotifier.value = m,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                gradient: sel ? AppColors.brand : null,
                borderRadius: BorderRadius.circular(11),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, size: 15, color: sel ? Colors.white : p.sub),
                  const SizedBox(width: 4),
                  Text(label,
                      style: GoogleFonts.inter(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: sel ? Colors.white : p.sub)),
                ],
              ),
            ),
          );
        }

        return Container(
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: p.fill,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              seg('Koyu', Icons.dark_mode_outlined, ThemeMode.dark),
              seg('Açık', Icons.light_mode_outlined, ThemeMode.light),
            ],
          ),
        );
      },
    );
  }
}

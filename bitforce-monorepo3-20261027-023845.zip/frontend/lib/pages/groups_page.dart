// Gruplar Sayfası
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:frontend/main.dart';

class Group {
  final String name, type, lastActive;
  final int members;
  final IconData icon;
  bool joined;
  Group(this.name, this.type, this.members, this.lastActive, this.icon,
      {this.joined = false});
}

final groupsNotifier = ValueNotifier<List<Group>>([
  Group('Veri Yapıları • 2. Sınıf', 'Ders', 48, 'Bugün',
      Icons.account_tree_outlined,
      joined: true),
  Group('Algoritma Çalışma Topluluğu', 'Çalışma', 32, '2 saat önce',
      Icons.psychology_outlined),
  Group('Mobil Uygulama Projesi', 'Proje', 7, 'Dün', Icons.phone_android),
  Group('Elektronik Devreler', 'Ders', 56, '3 gün önce', Icons.memory_outlined),
  Group('Girişimcilik Topluluğu', 'Çalışma', 120, 'Bu hafta',
      Icons.lightbulb_outline),
]);

class GroupsPage extends StatefulWidget {
  const GroupsPage({super.key});

  @override
  State<GroupsPage> createState() => _GroupsPageState();
}

class _GroupsPageState extends State<GroupsPage> {
  static const _types = ['Ders', 'Çalışma', 'Proje'];
  static const _filters = ['Tümü', ..._types];

  String _filter = 'Tümü';

  void _openCreate() {
    final p = Pal.of(context);
    final ctrl = TextEditingController();
    String type = 'Çalışma';
    showGlassSheet(
      context,
      title: 'Yeni Grup Oluştur',
      child: StatefulBuilder(
        builder: (ctx, setSheet) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: ctrl,
              style: p.body(14.5, color: p.text),
              decoration: glassField(p, 'Grup adı'),
            ),
            const SizedBox(height: 14),
            Text('Grup türü', style: p.body(12.5, w: FontWeight.w600)),
            const SizedBox(height: 8),
            FilterBar(
              options: _types,
              selected: type,
              onSelected: (t) => setSheet(() => type = t),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: GradientButton(
                label: 'Grubu Oluştur',
                icon: Icons.add_rounded,
                onTap: () {
                  final name = ctrl.text.trim();
                  if (name.isEmpty) return;
                  groupsNotifier.value = [
                    Group(name, type, 1, 'Şimdi', Icons.groups_outlined,
                        joined: true),
                    ...groupsNotifier.value,
                  ];
                  Navigator.pop(ctx);
                  toast(context, '"$name" grubu oluşturuldu');
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 130),
      children: [
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('MYO & Gruplar', style: p.h(22, w: FontWeight.w700)),
                  const SizedBox(height: 2),
                  Text('Toplulukları keşfet, ekibini kur.', style: p.body(13)),
                ],
              ),
            ),
            GradientButton(
              label: 'Grup Oluştur',
              icon: Icons.add_rounded,
              compact: true,
              onTap: _openCreate,
            ),
          ],
        ),
        const SizedBox(height: 20),
        FilterBar(
          options: _filters,
          selected: _filter,
          onSelected: (f) => setState(() => _filter = f),
        ),
        const SizedBox(height: 14),
        ValueListenableBuilder<List<Group>>(
          valueListenable: groupsNotifier,
          builder: (_, all, __) {
            final list = _filter == 'Tümü'
                ? all
                : all.where((g) => g.type == _filter).toList();
            return Column(
              children: [
                for (final g in list) ...[
                  _GroupCard(group: g),
                  const SizedBox(height: 12),
                ],
              ],
            );
          },
        ),
      ],
    );
  }
}

class _GroupCard extends StatelessWidget {
  final Group group;
  const _GroupCard({required this.group});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final c = catColor(group.type);
    return GlassCard(
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [c, c.withValues(alpha: 0.55)],
                  ),
                  boxShadow: [
                    BoxShadow(color: c.withValues(alpha: 0.35), blurRadius: 12),
                  ],
                ),
                child: Icon(group.icon, color: Colors.white, size: 26),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(group.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: p.h(14.5)),
                    const SizedBox(height: 6),
                    CategoryTag(group.type),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Icon(Icons.people_outline, size: 16, color: p.sub),
              const SizedBox(width: 5),
              Text('${group.members} üye', style: p.body(12.5)),
              const SizedBox(width: 14),
              Icon(Icons.schedule, size: 15, color: p.sub),
              const SizedBox(width: 5),
              Expanded(
                  child: Text(group.lastActive,
                      overflow: TextOverflow.ellipsis, style: p.body(12.5))),
              group.joined
                  ? _ChatButton(
                      onTap: () =>
                          toast(context, '${group.name} sohbeti açılıyor…'))
                  : GradientButton(
                      label: 'Katıl',
                      icon: Icons.login_rounded,
                      compact: true,
                      onTap: () {
                        group.joined = true;
                        groupsNotifier.value = List.of(groupsNotifier.value);
                        toast(context, 'Gruba katıldın');
                      },
                    ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ChatButton extends StatelessWidget {
  final VoidCallback onTap;
  const _ChatButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          color: AppColors.accent.withValues(alpha: 0.14),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.accent.withValues(alpha: 0.45)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.chat_bubble_outline,
                size: 16, color: AppColors.accent),
            const SizedBox(width: 6),
            Text('Sohbet Et',
                style: GoogleFonts.inter(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: AppColors.accent)),
          ],
        ),
      ),
    );
  }
}

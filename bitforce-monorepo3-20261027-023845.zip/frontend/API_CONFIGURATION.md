# API host configuration

The app reads its API root from the `API_BASE_URL` Dart define. For a physical
Android device, pass the development computer's reachable LAN address:

```sh
flutter run --dart-define=API_BASE_URL=http://192.168.1.20:8000
```

Use your own host address in place of `192.168.1.20`. The Android emulator
otherwise defaults to `http://10.0.2.2:8000`; web, iOS, and desktop default to
`http://127.0.0.1:8000`.

Android cleartext HTTP is enabled in the debug manifest only. Configure a
reachable HTTPS URL for release builds; do not enable cleartext traffic in the
release manifest.
